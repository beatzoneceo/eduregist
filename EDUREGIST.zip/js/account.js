function register(){
    document.getElementById('register').style.display = "block";
    document.getElementById('login').style.display = "none";
}

function login(){
    document.getElementById('register').style.display = "none";
    document.getElementById('login').style.display = "block";
}