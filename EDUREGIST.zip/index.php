<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles/index.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduRegist</title>
</head>
<body>
    <form method="post">
<h1 class="header">EduRegist</h1>
<input type="text" class="txtSearch" placeholder="Search" name="data">
<input type="submit" class="btnSearch"value="Find" name="btnSearch">
    

    </form>
    
   
    
</body>
</html>

<?php
ini_set('display_errors',0);
require "config.php";


$stored_Username = $_COOKIE['username'];
 $stored_Password = $_COOKIE['password'];

if($connection){


    $news = "SELECT * FROM `schools` WHERE 1 ORDER BY `school_name`   ASC  ";
    $news_query = mysqli_query($connection,$news);
  echo '<div class="news">';
    while($rowss = mysqli_fetch_assoc($news_query)){
        $school_name = $rowss['school_name'];
        $school_location = $rowss['school_location'];
        $school_type = $rowss['school_type'];
        $school_email = $rowss['schoo;l_email'];
        $school_contact_one = $rowss['school_contact_one'];
        $school_contact_two = $rowss['school_contact_two'];
        $school_motto = $rowss['school_motto'];
        $school_logo = $rowss['school_logo'];
        $school_image = $rowss['school_image'];
        $school_username = $rowss['school_username'];
        $school_password = $rowss['school_password'];
        $school_id = $rowss['school_id'];
        $school_date = $rowss['school_date'];
        $school_time = $rowss['school_time'];
        $school_class = $rowss['school_class'];

        

    
    }
    echo ' 
        <p class="trending">'.$school_name.'</p>
        <img src="src/new.jpg" class="photo">
        <button class="btnTop"><a href="apply.php?id='.$school_id.'"  class="cc">Apply</a></button>
     
';

    echo ' </div>';
    




   

    $sql = "SELECT * FROM `schools` WHERE `school_username` = '$stored_Username' AND `school_password` = '$stored_Password'";
    $query = mysqli_query($connection,$sql);
    if(mysqli_num_rows($query) <= 0){
        echo '<div class="account">
        <p class="account_link">Register</p>
    </div>';
 }else{

    while( $rows = mysqli_fetch_assoc($query)){
        $school_name = $rows['school_name'];
    }
    echo '<div class="account">
    <p class="account_link">'.$school_name.'</p>
</div>';


   


 }



  


    if(isset($_POST['btnSearch'])){
       $data = $_POST['data'];

      
        $search ="SELECT * FROM `schools` WHERE `school_name` LIKE '%$data%'";
       




     
       $sql_schools_query = mysqli_query($connection,$search);
       echo '<div class="display"><p class="header">Apply Now</p>';
       while($rows = mysqli_fetch_assoc($sql_schools_query)){
           $school_name = $rows['school_name'];
           $school_location = $rows['school_location'];
           $school_type = $rows['school_type'];
           $school_email = $rows['schoo;l_email'];
           $school_contact_one = $rows['school_contact_one'];
           $school_contact_two = $rows['school_contact_two'];
           $school_motto = $rows['school_motto'];
           $school_logo = $rows['school_logo'];
           $school_image = $rows['school_image'];
           $school_username = $rows['school_username'];
           $school_password = $rows['school_password'];
           $school_id = $rows['school_id'];
           $school_date = $rows['school_date'];
           $school_time = $rows['school_time'];
           $school_class = $rows['school_class'];
   
   
           echo '
           <div class="sch1"> 
           <img src="src/new.jpg"class="logo">
           <h2 class="name">'.$school_name.'</h2>
           <h4 class="category">'.$school_class.'</h4>
           <h6 class="location">Location: '.$school_location.'</h6>
   
           <p class="cnt1">Contact 1: '.$school_contact_one.'</p>
           <p class="cnt2">Contact 2: '.$school_contact_two.'</p>
           <p class="email">Email: '.$school_email.'</p>
           <button class="btnApply"><a href="apply.php?id='.$school_id.'"  class="cc">Apply</a></button>
       </div>
   ';
   
   
   
       }
       echo '</div>';


    }else{
        //Auto display

        $sql_schools = "SELECT * FROM `schools` WHERE 1";
        $sql_schools_query = mysqli_query($connection,$sql_schools);
        echo '<div class="display"><p class="header">Apply Now</p>';
        while($rows = mysqli_fetch_assoc($sql_schools_query)){
            $school_name = $rows['school_name'];
            $school_location = $rows['school_location'];
            $school_type = $rows['school_type'];
            $school_email = $rows['schoo;l_email'];
            $school_contact_one = $rows['school_contact_one'];
            $school_contact_two = $rows['school_contact_two'];
            $school_motto = $rows['school_motto'];
            $school_logo = $rows['school_logo'];
            $school_image = $rows['school_image'];
            $school_username = $rows['school_username'];
            $school_password = $rows['school_password'];
            $school_id = $rows['school_id'];
            $school_date = $rows['school_date'];
            $school_time = $rows['school_time'];
            $school_class = $rows['school_class'];
    
    
            echo '
    
        
        <div class="sch1"> 
            <img src="src/new.jpg"class="logo">
            <h2 class="name">'.$school_name.'</h2>
            <h4 class="category">'.$school_class.'</h4>
            <h6 class="location">Location: '.$school_location.'</h6>
    
            <p class="cnt1">Contact 1: '.$school_contact_one.'</p>
            <p class="cnt2">Contact 2: '.$school_contact_two.'</p>
            <p class="email">Email: '.$school_email.'</p>
            <button class="btnApply"><a href="apply.php?id='.$school_id.'"  class="cc">Apply</a></button>
        </div>
    ';
    
    
    
        }
        echo '</div>';
    


    }








}

?>