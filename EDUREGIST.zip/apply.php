<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles/apply.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Now !!</title>
</head>
<body>
    <form method="post">
    <div class="display">
        <h2 class="header">Dewure High School:Application Form</h2>
        <input type="text" class="txtName" placeholder="Enter Your Fullname" name="name">
        <select class="age" name="age">
            <option>Enter Your Age</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
            <option>6</option>
            <option>7</option>
            <option>8</option>
            <option>9</option>
            <option>10</option>
            <option>11</option>
            <option>12</option>
            <option>13</option>
            <option>14</option>
            <option>15</option>
            <option>16</option>
            <option>17</option>
            <option>18</option>
            <option>19</option>
            <option>20</option>
            <option>21</option>
            <option>22</option>
            <option>23</option>
            <option>24</option>
            <option>25</option>

        </select>
        <input type="text" class="txtPrevious" placeholder="Your Previous School Name" name="previous">
        <select class="year" name="year">
            <option>Year of Admission</option>
            <option>2024</option>
            <option>2025</option>
        </select>

        <select class="level" name="level">
            <option>Level</option>
            <option>ECD</option>
            <option>FORM 1</option>
            <option>FORM 5</option>
        </select>

        <input type="text" class="number" placeholder="Enter Your Phone Number" name="phone">
        <input type="text" class="email" placeholder="Enter Your Email" name="email">

        <input type="file" class="description" title="Add your results photo" name="description">
        <input type="submit" class="submit" value="submit" name="sendit">

    </div>
    </form>
</body>
</html>
<?php
require "config.php";
if($connection){
    if(isset($_POST['sendit'])){
        $name = $_POST['name'];
        $age = $_POST['age'];
        $previous = $_POST['previous'];
        $year = $_POST['year'];
        $level = $_POST['level'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $description = $_POST['description'];

        if($name == null){
            echo '<script>alert("Please Enter Your Name")</script>';
        }else{
            if($previous == null){
                echo '<script>alert("Please Enter Your Previous School")</script>';
            }else{
                if($phone == null){
                    echo '<script>alert("Please Enter Your Phone Number")</script>';
                }else{
                    if($email == null){
                        echo '<script>alert("Please Enter Your Email")</script>';
                    }else{
                        if($description ==null){
                            echo '<script>alert("Please Enter Your Description")</script>';
                        }else{

                            $date = date("y/m/d");
                            $time = date("h:i:sa");

                            $id = $_GET['id'];
                            $database = "application".$id;

                            if($id == null){
                                
                            }else{
                                ////
                                $count = 1;
                                $school_id= null;
                                while($count <= 8){
                                    $random = rand(1,9);

                                    $school_id = $school_id.$random;
                                    $count = $count +1;
                                }
                                $insert = "INSERT INTO `$database`(`name`, `level`, `age`, `school`, `phone`, `year`, `date`, `time`, `accepted`, `id`,`email`) VALUES ('$name','$level','$age','$previous','$phone','$year','$date','$time','false','$school_id','$email')";
                                $insert_query = mysqli_query($connection,$insert);
                                if($insert_query){
                                    echo '<script>alert("You have succesfully applied. Wait and check your email for reply")</script> ';
                                }else{
                                    echo '<script>alert("Failed Try Again") </script>';
                                }


                                ///
                            }






                        }
                    }

                }
            }
        }



    }

}

?>