<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/account.js"></script>
    <link rel="stylesheet" href="styles/account.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account</title>
</head>
<body>
    <img class="poster" src="src/new.jpg">
    
    <h1 class="header">EduRegist</h1>

<div class="display">



<div class="register" id="register">
    <div class="nav">
        <button class="btnRegister" onclick="register()" >Register</button>
        <button class="btnLogin" onclick="login()">Login</button>
    </div>
    <form method="post">
    <div class="details">
    <input type="text" class="txtSchoolName" placeholder="Enter School Name" name="school_name">
   
    <select class="txtSchoolLocation" name="school_location">
        <option value="none">Enter Your School Location</option>
        <option value="Masvingo">Masvingo</option>
        <option value="Harare">Harare</option>
        <option value="Bulawayo">Bulawayo</option>
        <option value="Midlands">Midlands</option>
        <option value="Matebeleland North">Matebeleland North</option>
        <option value="Matebeland South">Matebeland South</option>
        <option value="Manicaland">Manicaland</option>
        <option value="Mashonaland East">Mashonaland East</option>
        <option value="Mashonaland West">Mashonaland West</option>
        <option value="Mashonaland Central">Mashonaland Central</option>
    </select>

    <select class="txtSchoolType" name="school_class">
        <option value="primary">Primary [Day]</option>
        <option value="primary">Primary [Boarding]</option>
        <option value="Secondary">Secondary [Day]</option>
        <option value="Secondary">Secondary [Boarding]</option>
        <option value="highschool">High School [Day]</option>
        <option value="highschool">High School [Boarding]</option>
    </select>
    <input type="email" class="txtSchoolEamil" placeholder="Enter School Email Account" name="school_email">
    <input type="text" class="txtSchoolContact1" placeholder="Enter School First Contact" name="school_contact_one">
    <input type="text" class="txtSchoolContact2" placeholder="Enter School Other Conatact" name="school_contact_two">

    <select class="txtSchoolCategory" name="school_type">
        <option value="Private">Private School</option>
        <option value="Government">Government School</option>
        <option value="Christian">Christian School</option>
        <option value="Roman">Roman School</option>
        <option value="Dutch">Dutch School</option>
        <option value="Other">Other</option>
    </select>

    <input type="text" class="txtSchoolMotto" placeholder="Enter School Motto" name="school_motto">
    <p class="txtLogo">Logo</p>
    <input type="file" class="fileSchoolLogo" name="school_logo">

    <p class="txtImage">Image</p>
    <input type="file" class="fileSchoolImage" name="school_image">

    <input type="text" class="Username" placeholder="Username" name="school_username">
    <input type="password" class="Password" placeholder="Password" name="school_password">

    <p class="accept">Accept All Terms And Conditions</p>
    <input type="checkbox" class="chkAccept" name="terms">

    

    <input type="submit" class="buttonRegister"value="Register" name="register">
    </div>
</div>
</form>
<form method="post">
<div class="login" id="login">
    <div class="nav">
        <button class="btnRegister2" onclick="register()">Register</button>
        <button class="btnLogin2" onclick="login()">Login</button>
    </div>
    <div class="details">
   

    <input type="text" class="txt_username" placeholder="Username" name="username">
    <input type="password" class="txt_password" placeholder="Password" name="password">

    <input type="submit" class="buttonLogin"value="Login" name="login">
   <a class="forgot" href="#">forgot my password</a>


    </div>
</div>
</form>
</body>
</html>
<?php
require"config.php";

if(isset($_POST['login'])){
    /*This is where username and password are fetch from input boxes*/
    $username = $_POST['username'];
    $password = $_POST['password'];


    if($username == null){
        echo '<script>alert("Enter Your Login Username")</script>';
    }else{
        if($password== null){
            echo '<script>alert("Enter Your Login Password")</script>';
        }else{
            $login ="SELECT * FROM `schools` WHERE `school_username` = '$username' AND `school_password` = '$password'";
            $query_login = mysqli_query($connection,$login);
            if($query_login){
                if(mysqli_num_rows($query_login) <= 0){
                    /*outputs is the details are wrong*/
                    echo '<script>alert("Account Not Found")</script>';
                }else{
                    setcookie("username", $username,time()+ 86400 * 30,"/");
                    setcookie("password", $password,time()+ 86400 * 30,"/");
                    /*outputs is the details are correct*/
                    echo '<script>alert("Welcome")</script>';
                    echo '<script> location.href="profile/";</script>';
                }
            }

        }
    }
}

if(isset($_POST['register'])){
    $school_name = $_POST['school_name'] ;
    $school_location = $_POST['school_location'] ;
    $school_type = $_POST['school_type'] ;
    $school_class = $_POST['school_class'] ;
    $school_email = $_POST['school_email'] ;
    $school_contact_one = $_POST['school_contact_one'] ;
    $school_contact_two = $_POST['school_contact_two'] ;
    $school_motto = $_POST['school_motto'] ;
    $school_logo = $_POST['school_logo'] ;
    $school_image = $_POST['school_image'] ;
    $school_username = $_POST['school_username'] ;
    $school_password = $_POST['school_password'] ;
    $terms = $_POST['terms'] ;

    if($school_name == null){
        echo '<script>alert("Enter School Name")</script>';
    }else{
        if($school_location == null){
            echo '<script>alert("Enter School Location")</script>';
        }else{
            if($school_type == null ){
                echo '<script>alert("Enter School Type")</script>';
            }else{
                if($school_email == null){
                    echo '<script>alert("Enter School Email")</script>';
                }else{
                    if($school_contact_one == null){
                        echo '<script>alert("Enter School Contact 1")</script>';
                    }else{
                        if($school_contact_two == null){
                            echo '<script>alert("Enter School Contact 2")</script>';
                        }else{
                            if($school_motto == null){
                                echo '<script>alert("Enter School Motto")</script>';
                            }else{
                                if($school_logo == null ){
                                    echo '<script>alert("Enter School Logo")</script>';
                                }else{
                                    if($school_image == null){
                                        echo '<script>alert("Enter School Image")</script>';
                                    }else{
                                        if($school_username == null){
                                            echo '<script>alert("Enter School Username")</script>';
                                        }else{
                                            if($school_password == null){
                                                echo '<script>alert("Enter School Password")</script>';
                                            }else{
                                                if($school_class == null){
                                                    echo '<script>alert("Enter School Class")</script>';
                                                }else{

                                                    if($terms == false){
                                                        echo '<script>alert("If you want to create an account with us please accept Our terms and conditions")</script>';
                                                    }else{
                                                        if($connection){
                                                            $date = date("y/m/d");
                                                            $time = date("h:i:sa");

                                                            $count = 1;
                                                            $school_id= null;
                                                            while($count <= 8){
                                                                $random = rand(1,9);

                                                                $school_id = $school_id.$random;
                                                                $count = $count +1;
                                                            }

                                                            $account_name = "application".$school_id;

                                                            $main_sql = "CREATE TABLE `$account_name` (
                                                                `name` varchar(255) NOT NULL,
                                                                `level` varchar(255) NOT NULL,
                                                                `age` int(255) NOT NULL,
                                                                `school` varchar(255) NOT NULL,
                                                                `phone` varchar(255) NOT NULL,
                                                                `year` int(255) NOT NULL,
                                                                `date` date NOT NULL,
                                                                `time` time NOT NULL,
                                                                `accepted` tinyint(1) NOT NULL,
                                                               
                                                                `id` int(255) NOT NULL,
                                                                `email` varchar(255) NOT NULL
                                                              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
                                                              $main_query = mysqli_query($connection,$main_sql);


 
  

                                                            $sql ="INSERT INTO `schools`(`school_name`, `school_location`, `school_type`, `schoo;l_email`, `school_contact_one`, `school_contact_two`, `school_motto`, `school_logo`, `school_image`, `school_username`, `school_password`, `school_id`, `date`, `time`, `verified`, `school_class`) VALUES ('$school_name','$school_location','$school_type','$school_email','$school_contact_one','$school_contact_two','$school_motto','$school_logo','$school_image','$school_username','$school_password','$school_id','$date','$time','false','$school_class')";
                                                            $query = mysqli_query($connection,$sql);

                                                        }else{
                                                            echo '<script>alert("Database Not Found")</script>';
                                                        }




                                                    }
                                                 }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
   
    
}



?>