<?php
require "config.php";
$id = $_GET['id'];
$table = $_GET['table'];
$applications = "application".$table;


    $sql = "UPDATE `$applications` SET `accepted`=1 WHERE `id` = '$id' ";
    $query = mysqli_query($connection,$sql);
    if($query){
        echo 'accepted';
    }else{
        echo 'retry';
    }


?>