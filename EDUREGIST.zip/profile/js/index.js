

function detailsed(){
    var div_details = document.getElementById('details')
    var div_applications = document.getElementById('app_div')
    var div_a = document.getElementById('div_a')
    div_a.style.display = "none"
    div_details.style.display = "block"
    div_applications.style.display = "none"
    console.log("clicked")
}


function applications(){
    var div_details = document.getElementById('details')
    var div_applications = document.getElementById('app_div')
    var div_a = document.getElementById('div_a')
    div_a.style.display = "none"
    div_details.style.display = "none"
    div_applications.style.display = "block"
    console.log("clicked")
}

function accept(){
    var div_details = document.getElementById('details')
    var div_applications = document.getElementById('app_div')
    var div_a = document.getElementById('div_a')
    div_a.style.display = "block"
    div_details.style.display = "none"
    div_applications.style.display = "none"
    console.log("clicked")
}