<!DOCTYPE html>
<html lang="en">
<head>
    <script src="js/index.js"></script>
    <link rel="stylesheet" href="styles/index.css">
    <link rel="stylesheet" href="icons/icons/css/uicons-solid-rounded.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
</head>
<body>
   

<img src="src/logo.jpg"class="logo">
<button class="btnApplications" onclick="applications()">Applications</button>
<button class="btnAccepted" onclick="accept()">Accepted</button>
<button class="btnDetails" onclick="detailsed()">My Details</button>

<div class="profile_pic"><img class="img_profile" src="src/new.jpg"></div>




    
</body>
</html>
<?php
ini_set('display_errors',0);
require "config.php";
 $stored_Username = $_COOKIE['username'];
 $stored_Password = $_COOKIE['password'];

if($connection){
   

    $sql = "SELECT * FROM `schools` WHERE `school_username` = '$stored_Username' AND `school_password` = '$stored_Password'";
    $query = mysqli_query($connection,$sql);
    if(mysqli_num_rows($query) <= 0){
        echo '<script> location.href="http://127.0.0.1/eduRegist/";</script>';
 }else{

   while( $rows = mysqli_fetch_assoc($query)){
    $school_name = $rows['school_name'];
    $school_location = $rows['school_location'];
    $school_type = $rows['school_type'];
    $school_email = $rows['schoo;l_email'];
    $school_contact_one = $rows['school_contact_one'];
    $school_contact_two = $rows['school_contact_two'];
    $school_motto = $rows['school_motto'];
    $school_logo = $rows['school_logo'];
    $school_image = $rows['school_image'];
    $school_username = $rows['school_username'];
    $school_password = $rows['school_password'];
    $school_id = $rows['school_id'];
    $school_date = $rows['school_date'];
    $school_time = $rows['school_time'];
    $school_class = $rows['school_class'];


   }

   echo '  <title>'.$school_name.'</title> <h1 class="header">'.$school_name.' </h1>';



   echo '<div class="display">

   <div class="accepted" id="div_a">';
   /////////accepted

   
  $app = "application".$school_id;
  $accepted = "SELECT * FROM `$app` WHERE `accepted` = '1' ORDER BY `date` ASC";
  $accepted_query = mysqli_query($connection,$accepted);

  while($dataa = mysqli_fetch_assoc($accepted_query)){

   $a_name = $dataa['name'];
   $a_level = $dataa['level'];
   $a_age = $dataa['age'];
   $a_school = $dataa['school'];
   $a_phone = $dataa['phone'];
   $a_year = $dataa['year'];
   $a_date = $dataa['date'];
   $a_time = $dataa['time'];
   $a_email = $dataa['email'];
   

   echo '
  

   <div class="rol" title="'.$a_date.':'.$a_time.'">
   <p class="p_name">Name of the student:  '.$a_name.'</p>
   <p class="p_age">Age of the student: '.$a_age.'</p>
   <p class="p_previous">Previous School: '.$a_school.'</p>
   <p class="p_email">Email: '.$a_email.'</p>
   <p class="p_phone">Contact: '.$a_phone.'</p>
   <p class="p_level">Application Level: '.$a_level.'</p>
   <p class="p_adimmission">Year of Adimmission: '.$a_year.'</p>
   <img src="src/new.jpg" class="p_results">
   <button  class="txtAccepted">🎊🎊🎊🎊This Student Is Accepted🎊🎊🎊🎊</button>
   </div>




  
   
   ';

  }



   /////close accepted


   echo '
   
   </div>
   
   
   
   
   
   
   
   
   <div class="applications" id="app_div">
';

  $app = "application".$school_id;
   $applications = "SELECT * FROM `$app` WHERE `accepted` = '0'";
   $applications_query = mysqli_query($connection,$applications);
   $count = 1;
   while($data = mysqli_fetch_assoc($applications_query)){

    $p_name = $data['name'];
    $p_level = $data['level'];
    $p_age = $data['age'];
    $p_school = $data['school'];
    $p_phone = $data['phone'];
    $p_year = $data['year'];
    $p_date = $data['date'];
    $p_time = $data['time'];
    $p_email = $data['email'];
 $p_id = $data['id'];
    

    echo '
   

    <div class="rol" title="'.$p_date.':'.$p_time.'">
    <img src="src/stamp.jpg" class="stamp">
    <p class="p_name">Name of the student:  '.$p_name.'</p>
    <p class="p_age">Age of the student: '.$p_age.'</p>
    <p class="p_previous">Previous School: '.$p_school.'</p>
    <p class="p_email">Email: '.$p_email.'</p>
    <p class="p_phone">Contact: '.$p_phone.'</p>
    <p class="p_level">Application Level: '.$p_level.'</p>
    <p class="p_adimmission">Year of Adimmission: '.$p_year.'</p>
    <img src="src/new.jpg" class="p_results">
    <button  class="btnReject">Reject</button>
    <button  class="btnAccept" id="accept'.$count.'">Accept</button>
    </div>
 
 
 
 
   
    
    ';

    echo "<script>
                    document.getElementById('accept".$count."').addEventListener('click',acceptt);
                    function acceptt(){
                   
                     var id = '".$p_id."';
                     var table= '".$school_id."';
                     console.log(id)
                   
                     var xhr = new XMLHttpRequest;
                     xhr.open('GET','index_accept.php?id='+id+'&table='+table)
                     xhr.onload = function(){
                     if(this.status ==200){
                      var data = (this.responseText)
                      alert(data);
         
                     }
                     }
                     xhr.send();
         
                    }
         
                    </script>";

    $count = $count +1;

   }

 

echo '
</div>
   
   
   

   <div class="div_details" id="details">
       <img class="logoo" src="src/new.jpg"><p class="lbl_edit_logo">Edit Logo</p>
       <img class="image" src="src/new.jpg"><p class="lbl_edit_image">Edit Image</p>
       <div class="info">
           <p class="dd">School Name:    '.$school_name.'</p>
           <p class="dd">School Location: '.$school_location.'</p>
           <p class="dd">School Email: '.$school_email.'</p>
           <p class="dd">School Type: '.$school_type.'</p>
           <p class="dd">School Contact 1: '.$school_contact_one.'</p>
           <p class="dd">School Contact 2: '.$school_contact_two.'</p>
           <p class="dd">School Motto: '.$school_motto.'</p>
           <p class="dd">School Username: '.$school_username,'</p>
           <p class="dd">School Pasword: ********** </p>
           <p class="dd">School Class: '.$school_class.'</p>

           <button class="btn_logout">Logout</button>

       </div>

   </div>

</div>';



       
    }

}else{

    echo '<script> location.href="http://127.0.0.1/eduRegist/";</script>';
}


?>